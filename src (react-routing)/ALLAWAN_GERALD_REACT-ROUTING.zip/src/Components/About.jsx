export default function About(){
    return(
        <>
            <h1>Welcome to my About Page</h1>
            <p>This is written by: Gerald Prince B. Allawan</p>
        </>
    )
}